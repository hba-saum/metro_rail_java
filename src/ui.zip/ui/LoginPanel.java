package ui;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;


class LoginPanel extends JPanel{

    JLabel user = new JLabel("Username: ");
    JLabel pass = new JLabel("Password: ");
    JTextField userTf = new JTextField();
    JPasswordField passPf = new JPasswordField();
    JButton login = new JButton("Login");


    //box size
    

    public LoginPanel(){
        Font font = new Font(Font.SANS_SERIF, Font.BOLD, 20);

        setLayout(new GridBagLayout());
        GridBagConstraints gb = new GridBagConstraints();
        
        gb.gridx = 0;
        gb.gridy = 0;     
        add(user, gb);
        
        gb.gridx = 0;
        gb.gridy = 1;     
        add(userTf, gb);

        gb.gridx = 0;
        gb.gridy = 2;     
        add(pass, gb);

        gb.gridx = 0;
        gb.gridy = 3;     
        add(passPf, gb);


        gb.gridx = 0;
        gb.gridy = 4;     
        add(login, gb);

        //set the size 
        Dimension boxSize = new Dimension(300, 50);
        user.setPreferredSize(boxSize);
        pass.setPreferredSize(boxSize);
        userTf.setPreferredSize(boxSize);
        passPf.setPreferredSize(boxSize);
        login.setPreferredSize(boxSize);

        //sets font
        user.setFont(font);
        pass.setFont(font);
        userTf.setFont(font);
        passPf.setFont(font);
        login.setFont(font);
    }
}