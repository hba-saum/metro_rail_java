package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class RegisterPanel extends JPanel{
    
}