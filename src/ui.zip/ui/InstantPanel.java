package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


class InstantPanel extends JPanel implements ActionListener{
    int ticketPrice = 5;
    JLabel instTicket = new JLabel("Buy Instant Ticket");
    JLabel from = new JLabel("From: ");
    JLabel to = new JLabel("To: ");
    JLabel fair = new JLabel(" ");
    JButton nextBtn = new JButton("Next");
    String[] location = {"UTTRA NORTH","UTTRA CENTER","UTTRA SOUTH",
                        "PALLABI","MIRPUR 11","MIRPUR 10","KAZIPARA",
                        "SHWRAPARA","AGARGAON","BIJOY-SARANI","FRAM-GATE",
                        "KAWRAN-BAZAR","SHAHBAG","DHAKA-UNIVERSITY",
                        "BANGLADESH SCRETARIAT","MOTIJHEEL"};
    JComboBox fromCb = new JComboBox<String>(location);
    JComboBox toCb = new JComboBox<String>(location);
    
    JLabel name= new JLabel("Name:");
    JLabel phone= new JLabel("Phone number:");
    JTextField tname=new JTextField();
    JTextField tphone=new JTextField();
    JButton bnext=new JButton("Next");
    //pay type
    JLabel payType = new JLabel("Select Payment Type: ");
    JRadioButton cardR = new JRadioButton("Card");
    JRadioButton bkashR = new JRadioButton("BKash");
    JRadioButton mcardR = new JRadioButton("MCard");
    ButtonGroup pay = new ButtonGroup();
    


    public InstantPanel(){
        pay.add(cardR);
        pay.add(bkashR);
        pay.add(mcardR);
    
        Font font = new Font(Font.SANS_SERIF, Font.BOLD, 15);
        Font txt =  new Font(Font.SANS_SERIF, Font.BOLD, 25);     
        setLayout(new GridBagLayout());
        GridBagConstraints gb = new GridBagConstraints();

        gb.gridx = 0;
        gb.gridy = 0;
        add(instTicket, gb);

        gb.gridx = 0;
        gb.gridy = 1;
        add(from, gb);

        gb.gridx = 1;
        gb.gridy = 1;
        add(fromCb, gb);

        gb.gridx = 0;
        gb.gridy = 2;
        add(to, gb);

        gb.gridx = 1;
        gb.gridy = 2;
        add(toCb, gb);

        gb.gridx = 1;
        gb.gridy = 3;
        add(fair, gb);

        gb.gridx = 0;
        gb.gridy = 4;
        add(name, gb);

        gb.gridx = 1;
        gb.gridy = 4;
        add(tname, gb);

        gb.gridx = 0;
        gb.gridy = 5;
        add(phone, gb);
        
        gb.gridx = 1;
        gb.gridy = 5;
        add(tphone, gb);

        gb.gridx = 0;
        gb.gridy = 6;
        add(payType, gb);
        
        gb.gridx = 1;
        gb.gridy = 6;
        add(cardR, gb);

        gb.gridx = 1;
        gb.gridy = 7;
        add(bkashR, gb);

        gb.gridx = 1;
        gb.gridy = 8;
        add(mcardR, gb);
        
        gb.gridx = 0;
        gb.gridy = 9;
        add(nextBtn, gb);

        //set the size 
        Dimension size = new Dimension(300, 50);
        fromCb.setPreferredSize(size);
        toCb.setPreferredSize(size);
        from.setPreferredSize(size);
        to.setPreferredSize(size);
        fair.setPreferredSize(size);
        
        name.setPreferredSize(size);
        tname.setPreferredSize(size);
        phone.setPreferredSize(size);
        tphone.setPreferredSize(size);
        nextBtn.setPreferredSize(size);
        payType.setPreferredSize(size);
        cardR.setPreferredSize(size);
        bkashR.setPreferredSize(size);
        mcardR.setPreferredSize(size);

        //set font
        fromCb.setFont(font);
        toCb.setFont(font);
        from.setFont(txt);
        instTicket.setFont(txt);
        to.setFont(txt);
        fair.setFont(txt);
        nextBtn.setFont(font);
        name.setFont(txt);
        phone.setFont(txt);
        tname.setFont(font);
        tphone.setFont(font);
        payType.setFont(txt);
        cardR.setFont(txt);
        bkashR.setFont(txt);
        mcardR.setFont(txt);

        fromCb.addActionListener(this);
        toCb.addActionListener(this);
        nextBtn.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        if(fromCb.getSelectedIndex()==toCb.getSelectedIndex()){
            fair.setText("Can not visit!");
        }else{
            int a = fromCb.getSelectedIndex();
            int b = toCb.getSelectedIndex();

            int price = Math.abs(((a+1)-(b+1))*ticketPrice);
            fair.setText("TK: " + price + "/=");

        }

    }
    


}